from input import *
import os 
# from  board import *
# from objects import *
from global_variables import *

if __name__ == "__main__":
    obj1 = Get()
    global_variables.flag = 0
    while(1):
        main_paddle.clear()
        main_ball.clear()
        val = input_to(obj1)

        sys.stdout.write("\033c")
        # print(val)
        # print(main_paddle.current_position_y)
        
        if val == 'q':
            break
        elif val == 'x':
            if global_variables.flag == 0:
                main_ball.speed()
                global_variables.flag = 1
        elif val == 'a': 
            if global_variables.flag == 0:
                main_ball.update_x_position(-2)
                # flag = 1
                # main_ball.speed()       
            # if main_paddle.current_position_x > 3 :
            main_paddle.update_x_position(-2)
            
        elif val == 'd':
            if global_variables.flag == 0:
                main_ball.update_x_position(2)
                # main_ball.speed()
                # flag = 1
            # if main_paddle.current_position_x < 128 :
            
            main_paddle.update_x_position(2)
        # main_board = board.Board()
        main_ball.render()
        main_paddle.render()
        main_board.render()

        