from board import *
from objects import *
from config import *

main_board = Board()

main_paddle = Paddle(paddle , 5 , 35 ,lives)

main_ball = Ball(ball , 5 , 34)

flag = 0