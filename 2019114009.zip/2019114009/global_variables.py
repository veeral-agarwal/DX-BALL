from board import *
from objects import *
from config import *
import random
import numpy as np
main_board = Board()

main_paddle = Paddle(paddle , 5 , 35 ,lives)

main_ball = Ball(ball , 5 , 34)

# main_brick_1 = Brick(brick , 10 , 10 , random.randint(1,2))

bricks_coor = []
bricks1 = []
bricks2 = []
bricks3 = []
bricks4 = []

bricks = [bricks1 , bricks2 , bricks3 , bricks4 ]

# for i in range(0 , 90 , 7):
#     bricks2.append(Brick(brick,i+5,11,np.inf))

def randomizer():
    if random.randint(1,4)==1: 
        return np.inf 
    else : 
        return random.randint(1,3)

for i in range(0 , 90 , 3):
    # temp = 
    bricks4.append(Brick(brick , i+5,5 ,randomizer() ))
    bricks1.append(Brick(brick , i+5,6 , randomizer() )) 
    bricks2.append(Brick(brick , i+5,10 , randomizer()))
    bricks3.append(Brick(brick , i+5,8 , randomizer() )) 
    bricks_coor.append((i+5 , 9))

flag = 0
powerupflag_thru_ball = 0
powerupflag_fast_ball = 0
powerupflag_expand_paddle = 0
powerupflag_shrink_paddle = 0
powerupflag_ball_multiplier = 0
powerupflag_paddle_grab = 0
powerups = [powerupflag_ball_multiplier , powerupflag_expand_paddle , powerupflag_fast_ball , powerupflag_paddle_grab , powerupflag_shrink_paddle , powerupflag_thru_ball]
powerups_name = ["powerupflag_ball_multiplier" , "powerupflag_expand_paddle" , "powerupflag_fast_ball" , "powerupflag_paddle_grab" , "powerupflag_shrink_paddle" , "powerupflag_thru_ball"]

total_time = 0

def render_all_bricks():
    for j in bricks:
        for i in j:
            i.render()
            i.collision_ball_brick()
    
def powerup_top_string():
    active_powerups = []
    for i in powerups:
        if i == 0:
            active_powerups.append( powerups_name[i] )
    print(active_powerups)
