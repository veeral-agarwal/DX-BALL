import global_variables
import config
from time import time,sleep
import random

class Objects():

    def __init__(self , obj , xpos , ypos):
        self.position_x = xpos
        self.position_y = ypos
        self.height = len(obj)
        self.width = len(obj[0])
        self.shape = obj

    def update_x_position(self , x):
        if self.position_x<=1:
            self.position_x=2
        if self.position_x>=90:
            self.position_x=90
        if self.position_x>1 and self.position_x<=90:
            self.position_x += x

    def update_y_position(self , y):
        self.position_y += y

    def current_position_x(self):
        return self.position_x

    def current_position_y(self):
        return self.position_y

    def clear(self):
        for i in range(self.width):
            for j in range(self.height):
                global_variables.main_board.matrix[j+self.position_y][i+self.position_x] = " "

    def render(self):
        for i in self.width:
            for j in self.height:
                global_variables.main_board.matrix[j+self.position_y][i+self.position_x] = self.shape[j][i]

class Paddle(Objects):

    def __init__(self ,obj , xpos , ypos, lives):
        self.initial_lives = 5
        super().__init__(obj , xpos , ypos)
        

    def lives(self):
        return self.initial_lives

    def render(self):
        for i in range(self.width):
            for j in range(self.height):
                global_variables.main_board.matrix[j+self.position_y][i+self.position_x] = self.shape[j][i]

class Ball(Objects):

    def __init__(self ,obj , xpos , ypos):
        # self.initial_lives = 5
        super().__init__(obj , xpos , ypos)
        self.speed_x = 0
        self.speed_y = 0
        
    # def lives(self):
    #     return self.initial_lives

    def speed(self):
        self.speed_x = 1
        self.speed_y = 1

    def collision_with_wall(self):
        if self.position_x<=1 or self.position_x>=99:
            self.speed_x *= -1
        if self.position_y<=4:
            self.speed_y *= -1
        elif self.position_y>=10:
            default()
            # pass

    def render(self):
        self.collision_with_wall()
        self.position_x += self.speed_x
        self.position_y -= self.speed_y
        for i in range(self.width):
            for j in range(self.height):
                global_variables.main_board.matrix[j+self.position_y][i+self.position_x] = self.shape[j][i]

def default():
    # print("x")
    # global_variables.main_paddle.clear()
    # global_variables.main_ball.clear()
    config.lives -= 1
    global_variables.main_ball.speed_x = 0
    global_variables.main_ball.speed_y = 0
    # global_variables.flag = 0
    global_variables.main_paddle = Paddle(config.paddle , 5 , 35 ,config.lives)
    global_variables.main_ball = Ball(config.ball , 5 , 34)