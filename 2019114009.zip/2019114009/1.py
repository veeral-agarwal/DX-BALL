import time
print(time.time())
print("This is printed immediately.")
time.sleep(2.4)
print("This is printed after 2.4 seconds.")
print(round(time.time()))