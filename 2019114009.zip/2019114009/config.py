import os
import sys
import termios, tty, time
from colorama import init, Fore, Back, Style
import objects
from math import pi
import numpy as np 

columns = 100
rows = 40

paddle = [['T','T','T','T','T'], ['T','T','T','T','T'] ]
lives = 5

ball = [['*']]