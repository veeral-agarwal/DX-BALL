from board import *
from objects import *
from config import *
import random
main_board = Board()

main_paddle = Paddle(paddle , 5 , 35 ,lives)

main_ball = Ball(ball , 5 , 34)

main_brick_1 = Brick(brick , 10 , 10 , 1)

bricks_coor = []
bricks = []
for i in range(90):
    temp = Brick(brick , i+5,20 , 1 )
    bricks.append(temp) 
    bricks_coor.append((i+5 , 20))

flag = 0