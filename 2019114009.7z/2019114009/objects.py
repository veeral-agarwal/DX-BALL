import global_variables
import numpy as np
import config
from colorama import Fore, init , Back , Style
init()
from time import time,sleep
import random

class Objects():

    def __init__(self , obj , xpos , ypos):
        self.position_x = xpos
        self.position_y = ypos
        self.height = len(obj)
        self.width = len(obj[0])
        self.shape = obj

    def update_x_position(self , x):
        if self.position_x<=4:
            self.position_x=4
        if self.position_x>=90:
            self.position_x=90
        if self.position_x>1 and self.position_x<=90:
            self.position_x += x

    def update_y_position(self , y):
        self.position_y += y

    def current_position_x(self):
        return self.position_x

    def current_position_y(self):
        return self.position_y

    def clear(self):
        for i in range(self.width):
            for j in range(self.height):
                global_variables.main_board.matrix[j+self.position_y][i+self.position_x] = " "

    # def render(self):
    #     for i in range(self.width):
    #         for j in range(self.height):
    #             global_variables.main_board.matrix[j+self.position_y][i+self.position_x] = self.shape[j][i]

class Paddle(Objects):

    def __init__(self ,obj , xpos , ypos, lives):
        self.initial_lives = 5
        super().__init__(obj , xpos , ypos)
        

    def lives(self):
        return self.initial_lives

    def render(self):
        for i in range(self.width):
            for j in range(self.height):
                global_variables.main_board.matrix[j+self.position_y][i+self.position_x] = self.shape[j][i]

class Ball(Objects):

    def __init__(self ,obj , xpos , ypos):
        # self.initial_lives = 5
        super().__init__(obj , xpos , ypos)
        self.speed_x = 0
        self.speed_y = 0
        
    # def lives(self):
    #     return self.initial_lives

    def speed(self):
        self.speed_x = 1
        self.speed_y = 1

    def collision_with_wall(self):
        if self.position_x + self.speed_x<=1 or self.position_x+self.speed_x>=96:
            self.speed_x *= -1
        if self.position_y<=4:
            self.speed_y *= -1
        elif self.position_y>=37:
            default()
            self.speed_x = 0
            self.speed_y = 0
            # pass

    def render(self):
        print(config.lives)
        self.collision_with_wall()
        self.collision_with_paddle()
        self.position_x += self.speed_x
        self.position_y -= self.speed_y
        for i in range(self.width):
            for j in range(self.height):
                global_variables.main_board.matrix[j+self.position_y][i+self.position_x] = self.shape[j][i]

    def collision_with_paddle(self):
        # print("111")
        # print(global_variables.main_board.matrix[self.position_y][self.position_x])
        if self.position_y == 35:
            if self.position_x == global_variables.main_paddle.position_x:
                self.speed_y *= -1
                self.speed_x -= 2
            elif self.position_x == global_variables.main_paddle.position_x+1:
                self.speed_y *= -1
                self.speed_x -= 1
            elif self.position_x == global_variables.main_paddle.position_x+2:
                self.speed_y *= -1
            elif self.position_x == global_variables.main_paddle.position_x+3:
                self.speed_y *= -1
                self.speed_x += 1
            elif self.position_x == global_variables.main_paddle.position_x+4:
                self.speed_y *= -1
                self.speed_x +=2
            # print("toto")

class Brick(Objects):
    def __init__(self, obj , xpos , ypos, weight):
        super().__init__(obj , xpos , ypos)
        self.weight = weight
        self.score = 0
        self.flag = 0

    def render(self):
        # print(self.flag)
        # print(Back.RED + "lololol")
        # print(self.width , self.height)
        for i in range(self.width):
            # lol = []
            for j in range(self.height):
                # print(Back.RED)
                # print(self.shape[j][i])
                # grid[row][i] = "\033[34m" + char + "\033[0m"
                if self.flag == 0:
                    if self.weight == 1:
                        global_variables.main_board.matrix[j+self.position_y][i+self.position_x] = ( "\033[34m" + self.shape[j][i] + "\033[0m" )
                    elif self.weight == 2:
                        global_variables.main_board.matrix[j+self.position_y][i+self.position_x] = ( Fore.GREEN + self.shape[j][i] )
                    elif self.weight == 3:
                        global_variables.main_board.matrix[j+self.position_y][i+self.position_x] = ( Fore.RED + self.shape[j][i] )
                    elif self.weight == np.inf:
                        global_variables.main_board.matrix[j+self.position_y][i+self.position_x] = ( Fore.BLACK + self.shape[j][i] )
                else:
                    global_variables.main_board.matrix[j+self.position_y][i+self.position_x] =' '
                # lol.append(Fore.RED+(global_variables.main_board.matrix[j+self.position_y][i+self.position_x]))
            # print(''.join(lol))

    def collision_ball_brick(self):
        if self.position_x == global_variables.main_ball.position_x and self.position_y == global_variables.main_ball.position_y:
            # global_variables.main_board.matrix[self.position_y][self.position_x] = ' '
            self.score += 1
            self.flag = 1



def default():
    # print("x")
    global_variables.main_paddle.clear()
    global_variables.main_ball.clear()
    config.lives -= 1
    # global_variables.main_ball.speed_x = 0
    # global_variables.main_ball.speed_y = 0
    global_variables.flag = 0
    global_variables.main_paddle.position_x=5
    global_variables.main_paddle.position_y=35
    global_variables.main_ball.position_x=5
    global_variables.main_ball.position_y=33
    global_variables.main_ball.render()
    global_variables.main_paddle.render()