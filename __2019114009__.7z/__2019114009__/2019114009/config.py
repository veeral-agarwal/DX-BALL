import os
import sys
import termios, tty, time
from colorama import init, Fore, Back, Style
# import objects
from math import pi
import numpy as np 

columns = 100
rows = 40

paddle = [['T','T','T','T','T'], ['T','T','T','T','T'] ]
lives = 1
score = 0

thru_ball = [['t']]

ball = [['*']]
ball2 = [['o']]
brick = [['#','#','#']]