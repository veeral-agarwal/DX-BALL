import config
import random
from colorama import init, Fore, Back, Style
import numpy as np
import global_variables
# from global_variables import *
from time import sleep, time
init()
class Board():

    height = int(config.rows)
    length = int(config.columns)

    def __init__(self):
        self.matrix = [[ " " for i in range(self.length)] for j in range(self.height) ] 
        self.upperborder()
        self.lowerborder()
        self.begin_time = time()
        
    def render(self):
        global_variables.total_time = time()-self.begin_time
        print("lives left:",config.lives,"   score:" , config.score , "     time till now:",global_variables.total_time)
        global_variables.powerup_top_string()
        for y in range( self.height):                   #######
            lol = []
            for x in range( 0 , config.columns):
                # if (x,y) not in global_variables.bricks_coor:    
                    lol.append(self.matrix[y][x] + Style.RESET_ALL)
                # else:
                #     lol.append(Fore.RED + ("#" + Style.RESET_ALL) )
            # sleep(0.02)
            print(''.join(lol))

    def upperborder(self):
        for x in range(self.length):
            self.matrix[3][x] = "X"

    def lowerborder(self):
        for x in range(self.length):
            self.matrix[39][x] = "="

# pp = Board()
# pp.render()