from input import *
import os 
from time import sleep, time
# from  board import *
# from objects import *
from global_variables import *
import global_variables

if __name__ == "__main__":
    obj1 = Get()
    global_variables.flag = 0
    while(1):
        main_paddle.clear()
        main_ball.clear()
        # main_thruball.clear()
        val = input_to(obj1)
        # print(main_ball.shape)
        sys.stdout.write("\033c")
        # print(val)
        # print(main_paddle.current_position_y)
        if val != None:
            sleep(0.05)
        if val == 'q':
            break
        elif val == 'x':
            if global_variables.flag == 0:
                main_ball.speed()
                global_variables.flag = 1
        elif val == 'a':
            if global_variables.flag == 0:
                main_ball.update_x_position(-2)
                # flag = 1
                # main_ball.speed()       
            # if main_paddle.current_position_x > 3 :
            main_paddle.update_x_position(-2)
            
        elif val == 'd':
            if global_variables.flag == 0:
                main_ball.update_x_position(2)
                # main_ball.speed()
                # flag = 1
            # if main_paddle.current_position_x < 128 :
            
            main_paddle.update_x_position(2)
        # main_board = board.Board()

        # for i in thru:
        # main_thruball.render()
        # main_thruball.collision_ball_thruball()
        # main_thruball.collision_thruball_paddle()
        # main_thruball.render()

        # sleep(0.01)
        render_all_bricks()

        # main_brick_1.render()             
        main_ball.render()
        render_inair_powerup()
        # if(global_variables.total_time == 10):
        #     second_ball.render()
        # main_ball.collision_with_paddle()
        main_paddle.render()
        # sleep(0.00002)
        main_board.render()
    print("total time: ",global_variables.total_time,"   lives remaining: ",config.lives,"    score: ",config.score)
        