from board import *
from objects import *
from config import *
import random
import numpy as np
main_board = Board()

main_paddle = Paddle(paddle , 5 , 35 ,lives)

main_ball = Ball(ball , 5 , 34)

bricks_coor = []
bricks1 = []
bricks2 = []
bricks3 = []
bricks4 = []

bricks = [bricks1 , bricks2 , bricks3 , bricks4 ]

def randomizer():
    if random.randint(1,4)==1: 
        return np.inf 
    else : 
        return random.randint(1,3)

for i in range(0 , 90 , 3):
    # temp = 
    bricks4.append(Brick(brick , i+5,5 ,randomizer() , 6 ))
    bricks1.append(Brick(brick , i+5,6 , randomizer() , 6 )) 
    bricks2.append(Brick(brick , i+5,10 , 1 , 5 ))
    bricks3.append(Brick(brick , i+5,8 , randomizer() , 6 )) 
    bricks_coor.append((i+5 , 9))

flag = 0
powerupflag_thru_ball = 0
powerupflag_fast_ball = 0
powerupflag_expand_paddle = 0
powerupflag_shrink_paddle = 0
powerupflag_ball_multiplier = 0
powerupflag_paddle_grab = 0

active_powerupflag = [0,0,0,0,0,0]
inair_powerupflag = [0,0,0,0,0,0]

powerups = [powerupflag_ball_multiplier , powerupflag_expand_paddle , powerupflag_fast_ball , powerupflag_paddle_grab , powerupflag_shrink_paddle , powerupflag_thru_ball]
powerups_name = ["powerupflag_ball_multiplier" , "powerupflag_expand_paddle" , "powerupflag_fast_ball" , "powerupflag_paddle_grab" , "powerupflag_shrink_paddle" , "powerupflag_thru_ball"]

powerup_objects = []
# powerup_objects.append(thru_ball , 5,10,5)

total_time = 0

def render_all_bricks():
    for j in bricks:
        for i in j:
            i.render()
            i.collision_ball_brick()
    
def powerup_top_string():
    active_powerups = []
    for i in range(len(active_powerupflag)):
        if active_powerupflag[i] == 1:
            active_powerups.append( powerups_name[i] )
    print(active_powerups)

def render_inair_powerup():
    for i in powerup_objects:
        i.clear()
        if inair_powerupflag[5] == 1:
            i.render()