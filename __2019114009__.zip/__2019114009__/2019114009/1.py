# import time
# print(time.time())
# print("This is printed immediately.")
# time.sleep(2.4)
# print("This is printed after 2.4 seconds.")
# print(round(time.time()))
lol=0
pp = [lol]
print(pp[lol])
pp[lol] += 1
print(pp[lol])