from input import *
import os 
from time import sleep, time
# from  board import *
# from objects import *
from global_variables import *
import global_variables

if __name__ == "__main__":
    obj1 = Get()
    global_variables.flag = 0
    while(1):
        main_paddle.clear()
        main_ball.clear()
        val = input_to(obj1)
        sys.stdout.write("\033c")
        
        if val != None:
            sleep(0.05)
        
        if val == 'q':
            break
        
        elif val == 'x':
            if global_variables.flag == 0:
                main_ball.speed()
                global_variables.flag = 1
        
        elif val == 'a':
            if global_variables.flag == 0:
                main_ball.update_x_position(-2)

            main_paddle.update_x_position(-2)
            
        elif val == 'd':
            if global_variables.flag == 0:
                main_ball.update_x_position(2)
            
            main_paddle.update_x_position(2)

        render_all_bricks()

        main_ball.render()
        render_inair_powerup()
        main_paddle.render()
        main_board.render()
    print("total time: ",global_variables.total_time,"   lives remaining: ",config.lives,"    score: ",config.score)
    print(len(global_variables.explosion_coordinates))
    l1 = []
    cnt=0
    for i in global_variables.explosion_coordinates:
        if i not in l1:
            cnt+=1
            l1.append(i)
    print(cnt)